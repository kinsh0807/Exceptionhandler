package com.masai.webapp.example.controller;

import com.masai.webapp.example.entity.Post;
import com.masai.webapp.example.service.Post_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/api")
public class Mycontroller {
    @Autowired
    Post_Service service;

    @PostMapping ("/posting")
    public ResponseEntity<List<Post>>createPosts(@Validated @RequestBody Post post){
        List<Post>postList= service.createPost(post);
            return new ResponseEntity<List<Post>>(postList, HttpStatus.CREATED);
    }

}
